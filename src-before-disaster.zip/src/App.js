import React, { useState, useEffect } from "react";
import "./App.css";
import generatePassword from './tools'
// import image from './info.png'
// <img src={image} alt="Smiley face" width="32" className="App"/>

function App() {
  const [size, setSize] = useState(10);
  const [password, setPassword] = useState("null");

  return (
    <div>
      <h1 className="App">Password Generator</h1>
      

      <h2 className="App2">Enter size</h2>
      &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
      <input
        
        placeholder={size}
        onChange={e => {
          setSize(e.target.value);
        }}
      />
      {/* validate input : values only */}
      <br /><br />
      &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
      <button
        
        onClick={() => {
          var password = generatePassword(size)
          // console.log("pass: ", password);
          setPassword(password)
        }}
      >
        Submit
      </button>
      
      <h3 className="App2">{password}</h3>

      
    </div>
  );
}



export default App;
